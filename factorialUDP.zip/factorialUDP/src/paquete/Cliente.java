package paquete;

import java.io.*;
import java.net.*;

public class Cliente {

    static DatagramPacket paquete;
    static DatagramSocket socketCliente;
    static byte[] informacion;

    public static void iniciar() throws SocketException{

        socketCliente = new DatagramSocket();
        System.out.println("Cliente Iniciado...");

    
    }//iniciar

    public static void enviar(String numero)throws SocketException, IOException{
        System.out.println("Enviado "+numero);
        informacion = new byte[numero.length()];
        informacion = numero.getBytes();
        paquete = new DatagramPacket(informacion, informacion.length,new InetSocketAddress("127.0.0.1", 12345));
        socketCliente.send(paquete);
        System.out.println("Numero enviado..");

    
    }//enviar

}
