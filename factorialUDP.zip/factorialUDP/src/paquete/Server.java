
package paquete;

import java.io.IOException;
import java.net.*;


public class Server {

    static DatagramSocket s;
    
    public static void iniciar()throws SocketException, IOException{

         s= new DatagramSocket(12345);
         Recibe hilo = new Recibe(s);
    }


}
