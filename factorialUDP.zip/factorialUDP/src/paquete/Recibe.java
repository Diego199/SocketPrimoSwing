
package paquete;

import java.io.IOException;
import java.net.*;

public class Recibe extends Thread{

        private DatagramSocket s;
        static DatagramPacket recibido;
        static byte[] msg;
        public Recibe(DatagramSocket s){  
        this.s=s;
        msg=new byte[1024];
        System.out.print("Inicio");
        start();
        }//

        public void run(){
        try{


            while(true){
        recibido = new DatagramPacket(msg,1024);
        s.receive(recibido);

        int tam=recibido.getLength();
        String dato = new String(recibido.getData());
        dato= dato.substring(0,tam);
        dato=dato.trim();
        int valor = Integer.parseInt(dato);
        System.out.print("Numero "+valor);
        int fac = factorial.getValor(valor);
        System.out.print("Factorial "+fac);
    

        
    }//while

            }catch(IOException ioe){}


	}//run
}
